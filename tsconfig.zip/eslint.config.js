//  @ts-check

import { tanstackConfig } from "@tanstack/eslint-config";

export default [
    ...tanstackConfig,
    {
        rules: {
            "import/no-cycle": "off",
            "import/order": "off",
            "sort-imports": "off",
            "@typescript-eslint/array-type": "off",
            "@typescript-eslint/require-await": "off",
            "pnpm/json-enforce-catalog": "off",
        },
    },
    {
        ignores: [".output/**", "eslint.config.js", "prettier.config.js"],
    },
    {
        files: ["src/**/*.ts", "src/**/*.tsx"],
        rules: {
            "import/extensions": ["warn", "always"],
        },
    },
];
