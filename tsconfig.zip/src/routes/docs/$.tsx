import { createFileRoute, notFound } from "@tanstack/react-router";
import { DocsLayout } from "fumadocs-ui/layouts/docs";
import { createServerFn } from "@tanstack/react-start";
import { docs, source } from "@/lib/source";
import {
    DocsBody,
    DocsDescription,
    DocsPage,
    DocsTitle,
} from "fumadocs-ui/layouts/docs/page";
import { baseOptions } from "@/lib/layout.shared";
import { useFumadocsLoader } from "fumadocs-core/source/client";
import { Suspense } from "react";
import { useMDXComponents } from "@/components/mdx";
import { Header } from "@/components/general/Header";
import { Footer } from "@/components/general/Footer";
import "@/styles/docs.css";

export const Route = createFileRoute("/docs/$")({
    component: Page,
    loader: async ({ params }) => {
        const slugs = params._splat?.split("/") ?? [];
        const data = await serverLoader({ data: slugs });
        await docs.getPage(data.path)?.preload();
        return data;
    },
});

const serverLoader = createServerFn({
    method: "GET",
})
    .validator((slugs: string[]) => slugs)
    .handler(async ({ data: slugs }) => {
        const page = source.getPage(slugs);
        if (!page) throw notFound();

        return {
            path: page.path,
            pageTree: await source.serializePageTree(source.getPageTree()),
        };
    });

function Content({ path }: { path: string }) {
    const page = docs.getPage(path);
    if (!page) throw new Error(`unknown page: ${path}`);

    const { toc } = page;
    const MDX = page.body;

    return (
        <DocsPage toc={toc}>
            <DocsTitle>{page.title}</DocsTitle>
            <DocsDescription>{page.description}</DocsDescription>
            <DocsBody>
                <MDX components={useMDXComponents()} />
            </DocsBody>
        </DocsPage>
    );
}

function Page() {
    const data = useFumadocsLoader(Route.useLoaderData());

    return (
        <div className="docs-theme dark font-sans">
            <Header />
            <DocsLayout
                {...baseOptions()}
                tree={data.pageTree}
                sidebar={{ collapsible: false }}
            >
                <Suspense>
                    <Content path={data.path} />
                </Suspense>
            </DocsLayout>
            <Footer />
        </div>
    );
}
